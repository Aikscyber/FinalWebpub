document.addEventListener('DOMContentLoaded', function() {
    const products = document.querySelectorAll('.shop-item');

    // Handle heart rating clicks
    products.forEach((product) => {
        const heartRatings = product.querySelectorAll('.heart-rating');
        heartRatings.forEach((heart, index) => {
            heart.addEventListener('click', function() {
                const value = parseInt(heart.dataset.value);
                
                heartRatings.forEach((h, i) => {
                    h.classList.toggle('selected', i < value);
                });
            });
        });
    });

    // Handle add-to-cart functionality
    const addToCartButtons = document.getElementsByClassName('shop-item-button');
    Array.from(addToCartButtons).forEach(button => {
        button.addEventListener('click', addToCartClicked);
    });

    document.getElementsByClassName('btn-purchase')[0]?.addEventListener('click', purchaseClicked);

    function addToCartClicked(event) {
        const button = event.target;
        const shopItem = button.closest('.shop-item');
        const title = shopItem.querySelector('.shop-item-title').innerText;
        const price = shopItem.querySelector('.shop-item-price').innerText;
        const imageSrc = shopItem.querySelector('.shop-item-image').src;
        addItemToCart(title, price, imageSrc);
        updateCartTotal();
    }

    function addItemToCart(title, price, imageSrc) {
        const cartItems = document.getElementsByClassName('cart-items')[0];
        const cartItemNames = cartItems.getElementsByClassName('cart-item-title');
        
        for (let i = 0; i < cartItemNames.length; i++) {
            if (cartItemNames[i].innerText === title) {
                alert('This item is already added to the cart');
                return;
            }
        }

        const cartRow = document.createElement('div');
        cartRow.classList.add('cart-row');
        cartRow.innerHTML = `
            <div class="cart-item cart-column">
                <img class="cart-item-image" src="${imageSrc}" width="100" height="100">
                <span class="cart-item-title">${title}</span>
            </div>
            <span class="cart-price cart-column">${price}</span>
            <div class="cart-quantity cart-column">
                <input class="cart-quantity-input" type="number" value="1">
                <button class="btn btn-danger" type="button">REMOVE</button>
            </div>`;
        cartItems.append(cartRow);

        cartRow.querySelector('.btn-danger').addEventListener('click', removeCartItem);
        cartRow.querySelector('.cart-quantity-input').addEventListener('change', quantityChanged);
    }

    function removeCartItem(event) {
        event.target.closest('.cart-row').remove();
        updateCartTotal();
    }

    function quantityChanged(event) {
        const input = event.target;
        input.value = isNaN(input.value) || input.value <= 0 ? 1 : input.value;
        updateCartTotal();
    }

    function purchaseClicked() {
        alert('Thank you for your purchase');
        const cartItems = document.getElementsByClassName('cart-items')[0];
        while (cartItems.hasChildNodes()) {
            cartItems.firstChild.remove();
        }
        updateCartTotal();
    }

    function updateCartTotal() {
        const cartItemContainer = document.getElementsByClassName('cart-items')[0];
        const cartRows = cartItemContainer.getElementsByClassName('cart-row');
        let total = 0;

        Array.from(cartRows).forEach(cartRow => {
            const priceElement = cartRow.getElementsByClassName('cart-price')[0];
            const quantityElement = cartRow.getElementsByClassName('cart-quantity-input')[0];
            const price = parseFloat(priceElement.innerText.replace('P', ''));
            const quantity = parseInt(quantityElement.value);
            total += price * quantity;
        });

        document.getElementsByClassName('cart-total-price')[0].innerText = 'P' + total.toFixed(2);
    }

    // Search functionality
    const searchBar = document.getElementById('search-bar');
    searchBar.addEventListener('input', function(event) {
        const searchTerm = event.target.value.toLowerCase();
        products.forEach(product => {
            const title = product.querySelector('.shop-item-title').innerText.toLowerCase();
            product.style.display = title.includes(searchTerm) ? 'block' : 'none';
        });
    });

    // Image modal functionality
    function openModal(image) {
        const modal = document.getElementById("imageModal");
        const modalImg = document.getElementById("modalImage");
        
        modal.style.display = "block";
        modalImg.src = image.src;
    }

    function closeModal() {
        document.getElementById("imageModal").style.display = "none";
    }

    // Age verification
    document.getElementById('confirm-age').addEventListener('click', function() {
        document.getElementById('age-verification').style.display = 'none';
        document.getElementById('main-content').style.display = 'block';
    });

    document.getElementById('deny-age').addEventListener('click', function() {
        alert('You must be 18 or older to enter this site.');
        window.location.href = 'https://www.google.com';
    });
});
function initMap() {
    var businessLocation = { lat: 15.139, lng: 120.587 }; // Replace with your actual latitude and longitude
    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 15,
        center: businessLocation,
    });
    var marker = new google.maps.Marker({
        position: businessLocation,
        map: map,
        title: '4K Vape Shop',
    });
}

// Fetch only if age is confirmed
window.onload = function() {
    if (localStorage.getItem('ageConfirmed') === 'true') {
       fetch('http://localhost:3000/api/products')
          .then(response => response.json())
          .then(data => console.log(data))
          .catch(error => console.error('Error:', error));
    } else {
       alert('You must confirm your age to view this Website.');
    }
 };
window.addEventListener('load', initMap);

