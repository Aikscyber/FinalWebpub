const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const cors = require('cors');
app.use(cors());
app.use(bodyParser.json());

const productsData = [
  { id: 1, title: "ELF BAR Disposable Vape BC 5000 Puffs # Blue Razz Ice", price: 849, image: "Images/vape7.jpg" },
  { id: 2, title: "ELF BAR Disposable Vape BC 5000 Puffs # Cranberry Grape", price: 849, image: "Images/vape8.jpg" },
  { id: 3, title: "ELF BAR Disposable Vape BC 5000 Puffs # Mango Peach", price: 849, image: "Images/vape10.jpg" },
  { id: 4, title: "ELF BAR BC5000 Disposable Malaysian Mango 5000 Puffs 650mAh", price: 849, image: "Images/vape1.jpg" },
  { id: 5, title: "ELF BAR BC5000 Disposable Watermelon Cantaloupe Honeydew 5000 Puffs", price: 849, image: "Images/vape2.jpg" },
  { id: 6, title: "ELF BAR BC5000 Disposable 5000 Puffs Peach Berry", price: 849, image: "Images/vape3.jpg" },
  { id: 7, title: "ELF BAR BC5000 Disposable Guava Ice 5000 Puffs", price: 849, image: "Images/vape4.jpg" },
  { id: 8, title: "ELF BAR Disposable Vape BC 5000 Puffs # Strawberry Mango", price: 849, image: "Images/vape5.jpg" },
  { id: 9, title: "ELF BAR Disposable Vape BC 5000 Puffs # Sweet Menthol", price: 849, image: "Images/vape6.jpg" }
];

const customerData = [
  { id: 1, name: "Aiko Ocampo", email: "aikoocampo@gmail.com", joined: "2024-10-01" },
  { id: 2, name: "Aira Guiao", email: "airaguiao11@gmail.com", joined: "2024-10-02" },
  { id: 3, name: "Carl Paldeng", email: "carlpaldeng6@gmail.com", joined: "2024-10-11" },
  { id: 4, name: "Enrico Buan", email: "enribuan30@gmail.com", joined: "2024-10-28" }
];

const messagesData = [
  { id: 1, name: "Aiko Ocampo", email: "aikoocampo@gmail.com", message: "Interested in your products!", dateSent: "2024-10-25" },
  { id: 2, name: "Aira Guiao", email: "airaguiao@gmail.com", message: "Do you have any discounts?", dateSent: "2024-10-26" },
  { id: 2, name: "Aira Guiao", email: "airaguiao@gmail.com", message: "Hello, I was wondering if you have any new flavors or limited-edition vape products in stock. Could you please send me more details?", dateSent: "2024-10-27" },
  { id: 1, name: "Aiko Ocampo", email: "aikoocampo@gmail.com", message: "Could you explain your return and refund policy? What if I receive a product that doesn’t work properly?", dateSent: "2024-10-28" },
  { id: 3, name: "Carl Paldeng", email: "carlpaldeng6@gmail.com", message: "I’m interested in buying your products in puff. Do you offer wholesale pricing or discounts for larger orders?", dateSent: "2024-10-28" },

];

// Serve static files for HTML pages (including `customer-list.html`)
app.use(express.static('public'));

app.get('/', (req, res) => {
  res.send('Homepage. Available routes: GET /api/products, GET /api/customers, GET /api/messages');
});

app.get('/api/products', (req, res) => {
  res.json(productsData);
});

app.get('/api/products/:id', (req, res) => {
  const product = productsData.find(p => p.id === parseInt(req.params.id));
  product ? res.json(product) : res.status(404).send('Product not found.');
});

app.get('/api/customers', (req, res) => {
  res.json(customerData);
});

app.get('/api/customers/:id', (req, res) => {
  const customer = customerData.find(c => c.id === parseInt(req.params.id));
  customer ? res.json(customer) : res.status(404).send('Customer not found.');
});

app.get('/api/messages', (req, res) => {
  res.json(messagesData);
});

app.get('/api/messages/:id', (req, res) => {
  const message = messagesData.find(m => m.id === parseInt(req.params.id));
  message ? res.json(message) : res.status(404).send('Message not found.');
});

app.listen(3000, () => console.log('Server running on http://localhost:3000'));
